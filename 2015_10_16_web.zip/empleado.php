<?php
include_once('empleado.html');
?>